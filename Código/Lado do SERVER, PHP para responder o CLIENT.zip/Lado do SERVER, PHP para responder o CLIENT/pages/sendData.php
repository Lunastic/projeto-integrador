<?php

    header('Access-Control-Allow-Origin: *');

    require '../vendor/autoload.php';
    use Ivmelo\SUAP\SUAP;

    include '../index.php';

    if(isset($_POST['login'])){
        $username = $_POST['username'];
        $password = $_POST['password'];

        $type = $_POST['type'];
        $periodoLetivo = 0;
        $anoLetivo = 0;

        if($_POST['periodoletivo'] != null){
            $periodoLetivo = $_POST['periodoletivo'];
        }
        if($_POST['anoletivo'] != null){
            $anoLetivo = $_POST['anoletivo'];
        }

        try{
            $token = $suap->autenticar($username, $password);
            $suap->setToken($token['token']);
            //echo "<script>alert(".$username.")</script>";
            $token = $suap->autenticar($username, $password);
            $suap->setToken($token['token']);

            $meusDados = $suap->getMeusDados();
            if($type == 1){
                $meusDados = $suap->getMeuBoletim($anoLetivo, $periodoLetivo);
            }
            else if($type == 2){
                $meusDados = $suap->getTurmasVirtuais($anoLetivo, $periodoLetivo);
            }
            else if($type == 3){
                $meusDados = $suap->getHorarios($anoLetivo, $periodoLetivo);
            }
            else if($type == 4){
                $meusDados = $suap->getMeusPeriodosLetivos();
            }
            
            echo json_encode($meusDados);
        }catch(Exception $e){
            echo false;
        }
    }


?>